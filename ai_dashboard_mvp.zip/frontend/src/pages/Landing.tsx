import React, { useEffect, useState } from 'react';
import { ChartRenderer } from '../components/ChartRenderer';

const userProfile = {
  name: "张三",
  role: "风控经理",
  bizLine: "支付",
  country: "CN",
  permissions: ["view_risk", "view_priority"]
};

const reportMeta = [
  { name: "交易异常", country: "CN", risk: "高", priority: "高" },
  { name: "延迟清算", country: "CN", risk: "中", priority: "中" }
];

export const Landing = () => {
  const [dashboard, setDashboard] = useState([]);

  useEffect(() => {
    fetch('/api/generate-dashboard', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ userProfile, reportMeta })
    })
      .then(res => res.json())
      .then(setDashboard);
  }, []);

  return (
    <div style={{ padding: 24 }}>
      {dashboard.map((widget, i) => (
        <ChartRenderer key={i} widget={widget} />
      ))}
    </div>
  );
};