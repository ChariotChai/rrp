import React, { useEffect, useState } from 'react';
import { Card } from 'antd';
import { Bar, Line, Pie } from '@ant-design/charts';

export const ChartRenderer = ({ widget }) => {
  const [data, setData] = useState([]);

  useEffect(() => {
    fetch('/api/query-data', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ sql: widget.dataSource }),
    })
      .then(res => res.json())
      .then(setData);
  }, []);

  const ComponentMap = { bar: Bar, line: Line, pie: Pie };
  const ChartComp = ComponentMap[widget.type];

  return (
    <Card title={widget.title} style={{ marginBottom: 16 }}>
      <ChartComp data={data} xField={widget.xField} yField={widget.yField} autoFit />
    </Card>
  );
};