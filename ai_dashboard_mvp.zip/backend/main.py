from fastapi import FastAPI
from pydantic import BaseModel
from llm_service import generate_dashboard_config

app = FastAPI()

class DashboardRequest(BaseModel):
    userProfile: dict
    reportMeta: list

@app.post("/api/generate-dashboard")
def generate_dashboard(req: DashboardRequest):
    dashboard_config = generate_dashboard_config(req.userProfile, req.reportMeta)
    return dashboard_config