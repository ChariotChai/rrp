import openai
import os

openai.api_key = os.getenv("OPENAI_API_KEY")

def generate_dashboard_config(user_profile, report_meta):
    prompt = f"""
    当前用户画像：
    {user_profile}

    以下是报表元数据：
    {report_meta}

    请返回一个 JSON Dashboard 配置，包含多个 widget，每个 widget 包含：
    - type（bar/line/pie）
    - title
    - SQL 查询语句
    - xField, yField（图表字段）
    """
    res = openai.ChatCompletion.create(
        model="gpt-4",
        messages=[{"role": "user", "content": prompt}],
        temperature=0.3
    )
    return eval(res["choices"][0]["message"]["content"])